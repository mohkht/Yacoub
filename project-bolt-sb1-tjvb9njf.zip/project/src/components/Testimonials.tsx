import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Fatima Al-Zahra',
      location: 'Amman, Jordan',
      rating: 5,
      text: 'Excellent service at Yacoub Dental! Dr. Ahmad and his team made me feel comfortable throughout my treatment. The clinic is modern and clean. Highly recommend this dental clinic in Amman.',
      treatment: 'Dental Implants'
    },
    {
      name: 'Mohammed Hassan',
      location: 'Zarqa, Jordan',
      rating: 5,
      text: 'Best dental clinic in Jordan! My family has been going to Yacoub Dental for 3 years. Professional staff, advanced equipment, and pain-free procedures. Worth the drive from Zarqa.',
      treatment: 'Family Dentistry'
    },
    {
      name: 'Layla Qasemi',
      location: 'Amman, Jordan',
      rating: 5,
      text: 'Amazing cosmetic dentistry results! Dr. Sarah transformed my smile with veneers. The entire process was smooth and the results exceeded my expectations. Thank you Yacoub Dental team!',
      treatment: 'Cosmetic Dentistry'
    },
    {
      name: 'Omar Khatib',
      location: 'Irbid, Jordan',
      rating: 5,
      text: 'Outstanding orthodontic treatment! My braces experience was comfortable and the results are perfect. The team at Yacoub Dental is professional and caring. Highly recommended Amman dentist.',
      treatment: 'Orthodontics'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            What Our Patients Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real testimonials from satisfied patients who experienced exceptional dental care at our Amman clinic.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow relative"
            >
              <Quote className="absolute top-4 right-4 text-blue-200" size={32} />
              
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="text-yellow-400 fill-current" size={20} />
                ))}
              </div>

              <p className="text-gray-600 mb-6 leading-relaxed italic">
                "{testimonial.text}"
              </p>

              <div className="border-t pt-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-semibold text-gray-900">
                      {testimonial.name}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {testimonial.location}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                      {testimonial.treatment}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-blue-600 text-white p-8 rounded-lg">
            <h3 className="text-2xl font-bold mb-4">
              Ready to Join Our Happy Patients?
            </h3>
            <p className="text-blue-100 mb-6">
              Experience the best dental care in Amman, Jordan. Book your appointment today!
            </p>
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Schedule Your Visit
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;