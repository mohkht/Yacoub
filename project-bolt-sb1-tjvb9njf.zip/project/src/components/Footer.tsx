import React from 'react';
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Contact Information */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-blue-400">Contact Information</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone size={18} className="text-blue-400" />
                <span>+962 6 123 4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={18} className="text-blue-400" />
                <span>info@yacoubdental.jo</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin size={18} className="text-blue-400" />
                <span>123 Medical Center Street, Amman, Jordan</span>
              </div>
              <div className="flex items-center space-x-3">
                <Clock size={18} className="text-blue-400" />
                <span>Mon-Sat: 9:00 AM - 7:00 PM</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-blue-400">Our Services</h3>
            <ul className="space-y-2">
              <li className="hover:text-blue-400 transition-colors cursor-pointer">General Dentistry</li>
              <li className="hover:text-blue-400 transition-colors cursor-pointer">Cosmetic Dentistry</li>
              <li className="hover:text-blue-400 transition-colors cursor-pointer">Dental Implants</li>
              <li className="hover:text-blue-400 transition-colors cursor-pointer">Orthodontics</li>
              <li className="hover:text-blue-400 transition-colors cursor-pointer">Teeth Whitening</li>
              <li className="hover:text-blue-400 transition-colors cursor-pointer">Root Canal Treatment</li>
            </ul>
          </div>

          {/* About & Social */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-blue-400">Yacoub Dental</h3>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Providing exceptional dental care in Amman, Jordan. Our experienced team is committed to your oral health and beautiful smile.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 Yacoub Dental. All rights reserved. | Best dental clinic in Amman, Jordan</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;