import React from 'react';
import { GraduationCap, Award, Users } from 'lucide-react';

const Team = () => {
  const doctor = {
    name: 'Dr. Talal Al Yacoub',
    title: 'Chief Dentist & Founder',
    specialization: 'General & Cosmetic Dentistry, Dental Implants, Orthodontics',
    experience: '15 years',
    education: 'DDS - University of Jordan',
    image: 'https://images.pexels.com/photos/5998474/pexels-photo-5998474.jpeg?auto=compress&cs=tinysrgb&w=400'
  };

  return (
    <section id="team" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Meet Dr. Talal Al Yacoub
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your trusted dentist in Amman, committed to providing the highest quality dental care with advanced training and gentle expertise.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Doctor Image */}
            <div className="text-center lg:text-left">
              <div className="bg-gray-50 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow inline-block">
                <img
                  src={doctor.image}
                  alt={`${doctor.name} - ${doctor.title} at Yacoub Dental Amman`}
                  className="w-80 h-96 object-cover"
                />
              </div>
            </div>

            {/* Doctor Information */}
            <div className="space-y-6">
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-2">
                  {doctor.name}
                </h3>
                <p className="text-xl text-blue-600 font-semibold mb-4">
                  {doctor.title}
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  {doctor.specialization}
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center text-gray-600">
                  <Award size={20} className="mr-3 text-blue-600" />
                  <span className="text-lg">{doctor.experience} of experience</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <GraduationCap size={20} className="mr-3 text-blue-600" />
                  <span className="text-lg">{doctor.education}</span>
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-gray-900 mb-3 text-lg">About Dr. Talal</h4>
                <p className="text-gray-600 leading-relaxed">
                  Dr. Talal Al Yacoub is a highly experienced dentist dedicated to providing comprehensive dental care to families in Amman, Jordan. With 15 years of experience and advanced training, he specializes in general dentistry, cosmetic procedures, dental implants, and orthodontics, ensuring each patient receives personalized, gentle care.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-16">
          <div className="bg-blue-50 p-8 rounded-lg">
            <Users className="mx-auto mb-4 text-blue-600" size={48} />
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Why Choose Dr. Talal?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Expert Training</h4>
                <p className="text-gray-600 text-sm">
                  Advanced training from prestigious universities with continuous professional development and education.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Patient-Centered Care</h4>
                <p className="text-gray-600 text-sm">
                  Prioritizes patient comfort and works closely with each patient to achieve their oral health goals.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Modern Technology</h4>
                <p className="text-gray-600 text-sm">
                  Utilizes state-of-the-art equipment and the latest techniques for precise, comfortable treatments.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;